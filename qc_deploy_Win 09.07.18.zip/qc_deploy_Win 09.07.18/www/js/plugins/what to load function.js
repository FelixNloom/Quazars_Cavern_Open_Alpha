function loadWhatNow()
{
if ($gameVariables.value(1) == 8)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(3, $gameVariables.value(61)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(62)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(63)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(3, $gameVariables.value(64)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(65)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(66)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(3, $gameVariables.value(67)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(68)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(69)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(3, $gameVariables.value(70)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(71)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(72)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(3, $gameVariables.value(73)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(74)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(75)); //saves loot
		}
	}
else if ($gameVariables.value(1) == 7)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(3, $gameVariables.value(76)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(77)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(78)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(3, $gameVariables.value(79)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(80)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(81)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(3, $gameVariables.value(82)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(83)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(84)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(3, $gameVariables.value(85)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(86)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(87)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(3, $gameVariables.value(88)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(89)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(90)); //saves loot
		}	
	}
else if ($gameVariables.value(1) == 6)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(3, $gameVariables.value(91)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(92)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(93)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(3, $gameVariables.value(94)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(95)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(96)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(3, $gameVariables.value(97)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(98)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(99)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(3, $gameVariables.value(100)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(101)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(102)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(3, $gameVariables.value(103)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(104)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(105)); //saves loot
		}	
	}
else if ($gameVariables.value(1) == 5)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(3, $gameVariables.value(106)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(107)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(108)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(3, $gameVariables.value(109)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(110)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(111)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(3, $gameVariables.value(112)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(113)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(114)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(3, $gameVariables.value(115)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(116)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(117)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(3, $gameVariables.value(118)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(119)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(120)); //saves loot
		}	
	}
else if ($gameVariables.value(1) == 4)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(3, $gameVariables.value(121)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(122)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(123)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(3, $gameVariables.value(124)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(125)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(156)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(3, $gameVariables.value(127)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(128)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(129)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(3, $gameVariables.value(130)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(131)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(132)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(3, $gameVariables.value(133)); //saves room
			$gameVariables.setValue(4, $gameVariables.value(134)); //saves monster
			$gameVariables.setValue(5, $gameVariables.value(135)); //saves loot
		}	
	}
}