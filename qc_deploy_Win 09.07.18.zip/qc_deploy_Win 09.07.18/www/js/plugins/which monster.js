function monTell ()
{
if ($gameVariables.value(4) == 0)
	{
		//0 means no monster
		$gameMessage.add("There's no monster here.");
	} 
else if ($gameVariables.value(4) == 1)
	{
		var mon = "RAT";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 2)
	{
		mon = "SNEK";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 3)
	{
		mon = "GKC";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 4)
	{
		mon = "Evil Kiki";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 5)
	{
		mon = "Ashura";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 6)
	{
		mon = "Hammond";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 7)
	{
		mon = "Jeff";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 8)
	{
		mon = "Giant Cave Tick";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 9)
	{
		mon = "raging fungi";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 10)
	{
		mon = "xilef";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 11)
	{
		
		mon = "mfq";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 12)
	{
		mon = "capdr";
		printMonName(mon);
	}
else if ($gameVariables.value(4) == 13)
	{
		mon = "whiteye";
		printMonName(mon);
	}
}	