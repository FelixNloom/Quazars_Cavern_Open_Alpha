function speachMon()
	{
		if ($gameVariables.value(4) == 1)
			{
				$gameTemp.reserveCommonEvent(60);//rat
			}
		else if ($gameVariables.value(4) == 2)
			{
				$gameTemp.reserveCommonEvent(61); // snek
			}
		else if ($gameVariables.value(4) == 3)
			{
				$gameTemp.reserveCommonEvent(62); //gck
			}
		else if ($gameVariables.value(4) == 4)
			{
				$gameTemp.reserveCommonEvent(63); //gobchef
			}
		else if ($gameVariables.value(4) == 5)
			{
				$gameTemp.reserveCommonEvent(64); //ashura
			}
		else if ($gameVariables.value(4) == 6)
			{
				$gameTemp.reserveCommonEvent(65);//hammond
			}
		else if ($gameVariables.value(4) == 7)
			{
				$gameTemp.reserveCommonEvent(66);//meatless
			}
		else if ($gameVariables.value(4) == 8)
			{
				$gameTemp.reserveCommonEvent(67);//half-thing
			}
		else if ($gameVariables.value(4) == 9)
			{
				$gameTemp.reserveCommonEvent(68);//raging fungi
			}
		else if ($gameVariables.value(4) == 10)
			{
				$gameTemp.reserveCommonEvent(69);//xilef
			}
		else if ($gameVariables.value(4) == 11)
			{
				$gameTemp.reserveCommonEvent(70);//mfq
			}
		else if ($gameVariables.value(4) == 12)
			{
				$gameTemp.reserveCommonEvent(71);//capdr
			}
		else if ($gameVariables.value(4) == 13)
			{
				$gameTemp.reserveCommonEvent(72);//whiteye
			}
	}		