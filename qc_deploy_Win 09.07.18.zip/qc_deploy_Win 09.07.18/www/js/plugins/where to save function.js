function saveWhereNow ()
{
if ($gameVariables.value(1) == 8)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(61, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(62, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(63, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(64, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(65, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(66, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(67, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(68, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(69, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(70, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(71, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(72, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(73, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(74, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(75, $gameVariables.value(5)); //saves loot
		}
	}
else if ($gameVariables.value(1) == 7)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(76, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(77, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(78, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(79, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(80, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(81, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(82, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(83, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(84, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(85, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(86, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(87, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(88, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(89, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(90, $gameVariables.value(5)); //saves loot
		}	
	}
else if ($gameVariables.value(1) == 6)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(91, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(92, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(93, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(94, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(95, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(96, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(97, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(98, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(99, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(100, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(101, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(102, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(99) == 4)
		{
			$gameVariables.setValue(103, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(104, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(105, $gameVariables.value(5)); //saves loot
		}	
	}
else if ($gameVariables.value(1) == 5)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(106, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(107, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(108, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(109, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(110, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(111, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(112, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(113, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(114, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(115, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(116, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(117, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(118, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(119, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(120, $gameVariables.value(5)); //saves loot
		}	
	}
else if ($gameVariables.value(1) == 4)
	{
		if ($gameVariables.value(2) == 8)
		{
			$gameVariables.setValue(121, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(122, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(123, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 7)
		{
			$gameVariables.setValue(124, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(125, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(126, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 6)
		{
			$gameVariables.setValue(127, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(128, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(129, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 5)
		{
			$gameVariables.setValue(130, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(131, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(132, $gameVariables.value(5)); //saves loot
		}
		else if ($gameVariables.value(2) == 4)
		{
			$gameVariables.setValue(133, $gameVariables.value(3)); //saves room
			$gameVariables.setValue(134, $gameVariables.value(4)); //saves monster
			$gameVariables.setValue(135, $gameVariables.value(5)); //saves loot
		}	
	}
}	