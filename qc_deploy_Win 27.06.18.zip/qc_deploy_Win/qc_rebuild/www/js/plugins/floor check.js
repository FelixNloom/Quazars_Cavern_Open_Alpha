if (floor == b1)
	{
		b1();
	}
else if (floor == b2)
	{
		b2();
	}
else if (floor == b3)
	{
		b3();
	}
else if (floor == b4)
	{
		b4();
	}